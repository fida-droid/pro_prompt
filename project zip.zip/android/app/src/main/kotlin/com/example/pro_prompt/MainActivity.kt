package com.example.pro_prompt

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
